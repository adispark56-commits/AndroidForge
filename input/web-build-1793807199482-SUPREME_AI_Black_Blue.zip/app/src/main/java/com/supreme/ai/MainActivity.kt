package com.supreme.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var message: EditText
    private var language = "en-IN"
    private var torchOn = false
    private var flashCameraId: String? = null
    private val speechRequest = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        findFlashlight()
        makeInterface()
        greetByTime()
    }

    private fun makeInterface() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 20, 22, 18)
            setBackgroundColor(0xFF050A16.toInt())
        }
        val network = TextView(this).apply {
            text = "●  NETWORK ONLINE"
            textSize = 12f
            gravity = Gravity.START
            setTextColor(0xFF39D5FF.toInt())
        }
        val heading = TextView(this).apply {
            text = "SUPREME"
            textSize = 31f
            gravity = Gravity.CENTER
            setTextColor(0xFF38C8FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI ASSISTANT"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFF8BBDE0.toInt())
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 104f
            gravity = Gravity.CENTER
            setTextColor(0xFF16BFFF.toInt())
        }
        status = TextView(this).apply {
            text = "Initializing..."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFE6F7FF.toInt())
            minHeight = 64
        }
        val languagePicker = Spinner(this)
        languagePicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("English", "हिन्दी", "मराठी"))
        languagePicker.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                language = listOf("en-IN", "hi-IN", "mr-IN")[position]
                if (::tts.isInitialized) tts.language = Locale.forLanguageTag(language)
            }
        }
        message = EditText(this).apply {
            hint = "Type a message..."
            setHintTextColor(0xFF8BA8C0.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 8, 14, 8)
            setBackgroundColor(0xFF14243A.toInt())
        }

        page.addView(network, LinearLayout.LayoutParams(-1, 28))
        page.addView(heading, LinearLayout.LayoutParams(-1, 45))
        page.addView(subtitle, LinearLayout.LayoutParams(-1, 24))
        page.addView(orb, LinearLayout.LayoutParams(-1, 145))
        page.addView(status, LinearLayout.LayoutParams(-1, 65))
        page.addView(languagePicker, LinearLayout.LayoutParams(-1, 48))
        page.addView(message, LinearLayout.LayoutParams(-1, 52))
        page.addView(makeButton("🎙  TALK TO SUPREME") { listen() })
        page.addView(makeButton("SEND MESSAGE") { handleCommand(message.text.toString()) })
        page.addView(makeButton("FLASHLIGHT ON / OFF") { toggleFlashlight() })
        page.addView(makeButton("OPEN YOUTUBE") { openPackage("com.google.android.youtube") })
        page.addView(makeButton("OPEN WHATSAPP") { openPackage("com.whatsapp") })
        page.addView(makeButton("OPEN CAMERA") { launch(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)) })
        page.addView(makeButton("PHONE SETTINGS") { launch(Intent(android.provider.Settings.ACTION_SETTINGS)) })
        page.addView(makeButton("GOOGLE SEARCH") { googleSearch(message.text.toString()) })
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(0xFFBFEFFF.toInt())
            setBackgroundColor(0xFF102A45.toInt())
            setOnClickListener { action() }
        }

    private fun greetByTime() {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greeting = when (hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..20 -> "Good evening"
            else -> "Good night"
        }
        reply("$greeting. Supreme is ready.")
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), speechRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Supreme")
        }
        try { startActivityForResult(intent, speechRequest) }
        catch (_: Exception) { reply("Speech recognition is unavailable on this device.") }
    }

    @Deprecated("Legacy speech result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            message.setText(spoken)
            handleCommand(spoken)
        }
    }

    private fun handleCommand(raw: String) {
        val q = raw.trim()
        if (q.isEmpty()) return
        val lower = q.lowercase()
        when {
            lower.contains("youtube") -> { openPackage("com.google.android.youtube"); reply("Opening YouTube.") }
            lower.contains("whatsapp") -> { openPackage("com.whatsapp"); reply("Opening WhatsApp.") }
            lower.contains("camera") -> { launch(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)); reply("Opening camera.") }
            lower.contains("settings") -> { launch(Intent(android.provider.Settings.ACTION_SETTINGS)); reply("Opening settings.") }
            lower.contains("flashlight") || lower.contains("torch") -> { toggleFlashlight(); reply("Flashlight toggled.") }
            lower.startsWith("search ") -> { googleSearch(q.substringAfter("search ")); reply("Searching Google.") }
            lower.startsWith("call ") -> {
                val number = q.substringAfter("call ").filter { it.isDigit() || it == '+' }
                if (number.isNotBlank()) {
                    launch(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:$number")))
                    reply("Dialer opened. Please confirm the call.")
                } else reply("Please say the phone number.")
            }
            else -> askOnlineAi(q)
        }
    }

    private fun askOnlineAi(question: String) {
        val prefs = getSharedPreferences("supreme", MODE_PRIVATE)
        val savedKey = prefs.getString("gemini_key", null)
        if (savedKey.isNullOrBlank()) {
            val field = EditText(this).apply { hint = "Gemini API key"; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle("Connect AI")
                .setMessage("Add your Gemini API key. Keep it private.")
                .setView(field)
                .setPositiveButton("Save") { _, _ ->
                    val key = field.text.toString().trim()
                    prefs.edit().putString("gemini_key", key).apply()
                    if (key.isNotEmpty()) requestGemini(question, key)
                    else reply("An API key is needed for online AI conversations.")
                }.setNegativeButton("Cancel", null).show()
        } else requestGemini(question, savedKey)
    }

    private fun requestGemini(question: String, key: String) {
        status.text = "Supreme is thinking..."
        thread {
            var answer = "I couldn't connect. Check your internet and API key."
            try {
                val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
                val connection = endpoint.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.connectTimeout = 15000
                connection.readTimeout = 20000
                connection.setRequestProperty("Content-Type", "application/json")
                val escaped = question.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
                connection.outputStream.use {
                    it.write("""{"contents":[{"parts":[{"text":"$escaped"}]}]}""".toByteArray())
                }
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                val match = Regex(""""text"\s*:\s*"((?:\\.|[^"\\])*)"""").find(body)
                if (match != null) answer = match.groupValues[1]
                    .replace("\\n", "\n").replace("\\\"", "\"").replace("\\\\", "\\")
            } catch (_: Exception) { }
            runOnUiThread { reply(answer) }
        }
    }

    private fun reply(text: String) {
        status.text = text
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "supreme_reply")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale.forLanguageTag(language)
    }

    private fun findFlashlight() {
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            flashCameraId = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) { }
    }

    private fun toggleFlashlight() {
        try {
            val id = flashCameraId ?: run { reply("No flashlight found."); return }
            torchOn = !torchOn
            (getSystemService(CAMERA_SERVICE) as CameraManager).setTorchMode(id, torchOn)
        } catch (_: Exception) { reply("Flashlight is unavailable.") }
    }

    private fun openPackage(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) launch(intent) else reply("That app is not installed.")
    }

    private fun googleSearch(query: String) {
        if (query.isNotBlank()) launch(Intent(Intent.ACTION_VIEW,
            android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(query))))
    }

    private fun launch(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { reply("Couldn't open that feature.") }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        try {
            if (torchOn && flashCameraId != null)
                (getSystemService(CAMERA_SERVICE) as CameraManager).setTorchMode(flashCameraId!!, false)
        } catch (_: Exception) { }
        super.onDestroy()
    }
}
