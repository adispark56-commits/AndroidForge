# SUPREME AI Android starter

A black-and-blue native Android Kotlin starter with:
- English, Hindi and Marathi speech input selection
- Tap-to-talk speech recognition and text-to-speech
- Time-based greeting
- Launch YouTube, WhatsApp, Camera and Settings
- Flashlight toggle, Google search and dialer shortcut
- Optional Gemini API integration (you provide your own API key)

## Important limitations
- This is source code, **not an APK**.
- The wake phrase "Hey Supreme" is not implemented as an always-listening hotword. Use the Talk button.
- Android speech recognition depends on a speech-recognition service installed on the phone.
- AI chat needs internet and a Gemini API key. Keep the key private.
- Phone actions that can affect calls open the dialer for user confirmation.

## Build
Open this folder as an Android Studio project and build the debug APK, or use a compatible Android CI builder. Use JDK 17 and Android Gradle Plugin 8.6.1.
