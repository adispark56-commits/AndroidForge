# JARVIS AI for Android — starter build

This is a starter Android app project, not a precompiled APK. It includes:
- Tap-to-talk speech recognition through the Android speech service.
- Spoken replies using Android Text-to-Speech.
- English (India), Hindi and Marathi language selection.
- Basic commands: open YouTube/WhatsApp/Camera/Settings, flashlight toggle, Google search, and dialer.
- Optional Gemini API integration for general AI conversation.

## Important limitations
- **This version does not yet have an always-on “Hey Jarvis” wake word.** It listens after you tap the microphone. Reliable wake-word listening requires a dedicated offline wake-word engine, a foreground microphone service, battery optimization handling and explicit user consent. It should be added and tested as a separate stage.
- Sending WhatsApp messages, reading private messages, silently placing calls, and changing restricted system settings are not enabled. Calls open the dialer for confirmation.
- Gemini API usage may incur charges or be subject to Google's quotas. Keep your API key private. The key is stored in this app's private preferences, but this starter is not a hardened production security design.
- The app needs an Android device with speech recognition/TTS services installed. Speech recognition may send audio to the selected recognition provider.

## Build without a PC using GitHub Actions
1. Create a GitHub account and a new repository.
2. Upload the contents of this ZIP to the repository (keep the folder structure).
3. Open the **Actions** tab and run **Build JARVIS APK**.
4. When it finishes, open the workflow run and download the `JarvisAI-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk`. Android may ask you to allow installation from that source.

You can also open this project in Android Studio and build the debug APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Gemini API key
Create a key through Google AI Studio, then paste it into the app's optional key field. Do not share your key with anyone.
