package com.avk.jarvis

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import android.hardware.camera2.CameraManager
import android.content.Context
import android.provider.Settings
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject
import org.json.JSONArray
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private lateinit var keyInput: EditText
    private lateinit var spinner: Spinner
    private lateinit var tts: TextToSpeech
    private var torchOn = false
    private val requestCode = 7001
    private val prefs by lazy { getSharedPreferences("jarvis_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        heard = findViewById(R.id.heard)
        reply = findViewById(R.id.reply)
        keyInput = findViewById(R.id.apiKey)
        spinner = findViewById(R.id.languageSpinner)
        tts = TextToSpeech(this, this)

        val languages = listOf("English (India)", "Hindi", "Marathi")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages)
        keyInput.setText(prefs.getString("gemini_key", ""))
        findViewById<Button>(R.id.saveKey).setOnClickListener {
            prefs.edit().putString("gemini_key", keyInput.text.toString().trim()).apply()
            say("AI key saved on this device.")
        }
        findViewById<Button>(R.id.listenButton).setOnClickListener { listen() }
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) setTtsLanguage()
    }

    private fun selectedLocale(): Locale = when (spinner.selectedItemPosition) {
        1 -> Locale("hi", "IN")
        2 -> Locale("mr", "IN")
        else -> Locale("en", "IN")
    }

    private fun setTtsLanguage() {
        val result = tts.setLanguage(selectedLocale())
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.language = Locale.US
        }
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLocale().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try { startActivityForResult(intent, requestCode) }
        catch (_: Exception) { showReply("Speech recognition is unavailable. Install or enable Google speech services.") }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(request: Int, result: Int, data: Intent?) {
        super.onActivityResult(request, result, data)
        if (request == requestCode && result == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val command = words?.firstOrNull().orEmpty()
            if (command.isNotBlank()) {
                heard.text = command
                handleCommand(command)
            }
        }
    }

    private fun handleCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT)
        when {
            q.contains("open youtube") || q.contains("यूट्यूब खोल") || q.contains("youtube उघड") ->
                launchPackage("com.google.android.youtube", "Opening YouTube.")
            q.contains("open whatsapp") || q.contains("व्हाट्सऐप खोल") || q.contains("व्हॉट्सअॅप उघड") ->
                launchPackage("com.whatsapp", "Opening WhatsApp.")
            q.contains("open camera") || q.contains("कैमरा खोल") || q.contains("कॅमेरा उघड") ->
                launchIntent(Intent("android.media.action.IMAGE_CAPTURE"), "Opening camera.")
            q.contains("open settings") || q.contains("सेटिंग") ->
                launchIntent(Intent(Settings.ACTION_SETTINGS), "Opening settings.")
            q.contains("flashlight") || q.contains("torch") || q.contains("टॉर्च") || q.contains("फ्लॅशलाइट") ->
                toggleTorch()
            q.contains("call ") || q.contains("कॉल") || q.contains("फोन कर") ->
                showReply("For safety, open the dialer and confirm the number before calling.")
                    .also { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))) }
            q.startsWith("search ") || q.contains("search for") || q.contains("सर्च") || q.contains("खोज") ->
                searchWeb(raw)
            q.contains("volume up") || q.contains("आवाज बढ़") || q.contains("आवाज वाढ") ->
                showReply("Use your phone's volume-up button; Android restricts direct volume changes for ordinary apps.")
            else -> askGemini(raw)
        }
    }

    private fun launchPackage(pkg: String, message: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) { startActivity(launch); showReply(message) }
        else showReply("That app is not installed.")
    }

    private fun launchIntent(intent: Intent, message: String) {
        try { startActivity(intent); showReply(message) }
        catch (_: Exception) { showReply("I couldn't open that app.") }
    }

    private fun toggleTorch() {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (cameraId == null) { showReply("No flashlight found."); return }
            torchOn = !torchOn
            manager.setTorchMode(cameraId, torchOn)
            showReply(if (torchOn) "Flashlight switched on." else "Flashlight switched off.")
        } catch (_: Exception) { showReply("I couldn't control the flashlight.") }
    }

    private fun searchWeb(text: String) {
        val cleaned = text.replace(Regex("(?i)^search( for)?\\\\s*"), "").trim()
        val url = "https://www.google.com/search?q=" + Uri.encode(cleaned.ifBlank { text })
        launchIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Searching the web.")
    }

    private fun askGemini(question: String) {
        val apiKey = prefs.getString("gemini_key", "").orEmpty()
        if (apiKey.isBlank()) {
            showReply("I heard you. Add your Gemini API key below to enable AI conversations. You can still use supported phone commands.")
            return
        }
        showReply("Thinking...")
        thread {
            var answer = "Sorry, I couldn't reach the AI service."
            try {
                val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + Uri.encode(apiKey))
                val conn = endpoint.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject().put("system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                        "You are JARVIS, a concise, polite, futuristic personal assistant. Reply in the language used by the user: English, Hindi, or Marathi."))))
                    .put("contents", JSONArray().put(JSONObject().put("parts",
                        JSONArray().put(JSONObject().put("text", question)))))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(response)
                answer = root.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                conn.disconnect()
            } catch (_: Exception) { }
            runOnUiThread { showReply(answer) }
        }
    }

    private fun showReply(text: String) {
        reply.text = text
        say(text)
    }

    private fun say(text: String) {
        if (::tts.isInitialized) {
            setTtsLanguage()
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
